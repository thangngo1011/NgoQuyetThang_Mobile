package com.sinhvien.bai5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText edtSolarYear = findViewById(R.id.edtnamdl);
        TextView tvLunarYear = findViewById(R.id.textView4);
        Button btnConvert = findViewById(R.id.btn1);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String solarYearStr = edtSolarYear.getText().toString().trim();

                if (solarYearStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập năm dương lịch!", Toast.LENGTH_SHORT).show();
                    return;
                }

                int solarYear = Integer.parseInt(solarYearStr);
                String lunarYear = convertToLunarYear(solarYear);
                tvLunarYear.setText(lunarYear);
            }
        });
    }

    private String convertToLunarYear(int solarYear) {
        String[] lunarYears = {"Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"};
        String[] elements = {"Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"};
        int elementIndex = (solarYear - 4) % 10; // Can
        int lunarYearIndex = (solarYear - 4) % 12; // Chi

        return elements[elementIndex] + " " + lunarYears[lunarYearIndex];
    }
}